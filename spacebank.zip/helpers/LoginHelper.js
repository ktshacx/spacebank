import Web3 from "web3"
import { reactLocalStorage } from 'reactjs-localstorage';

const web3 = new Web3('https://bsc-dataseed.binance.org/')

function createAccount() {
    return(web3.eth.accounts.create())
}

function isLoggedIn() {
    if((reactLocalStorage.get('account') != "" && reactLocalStorage.get('password') != '') || (reactLocalStorage.get('account') && reactLocalStorage.get('password'))) {
        return true;
    }
    return false;
}

function isSessionAvaiable() {
    console.log(reactLocalStorage.get('loggedin'))
    if(reactLocalStorage.get('loggedin') == null || reactLocalStorage.get('loggedin') == "" || reactLocalStorage.get('loggedin') < Date.now()) {
        return false;
    }
    return true;
}

function getPassword() {
    return reactLocalStorage.get("password");
}

function addLoginSession() {
    reactLocalStorage.set("loggedin", Date.now() + 2 * 3600 * 1000 + "");
}

function getAccount() {
    return JSON.parse(reactLocalStorage.get('account'));
}

function getBalance() {
    return web3.eth.getBalance(getAccount()['address']);
}

function getAssets() {
    return JSON.parse(reactLocalStorage.get('assets'));
}

module.exports = {
    createAccount: createAccount,
    isLoggedIn: isLoggedIn,
    isSessionAvaiable: isSessionAvaiable,
    getPassword: getPassword,
    addLoginSession: addLoginSession,
    getAccount:getAccount,
    getBalance: getBalance
}