const currencyList = [
    {contract: "", name: "BNB"},
    {contract: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c", name: "WBNB", decimal: 18},
    {contract: "0x55d398326f99059ff775485246999027b3197955", name: "USDT", decimal: 18},
    {contract: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56", name: "BUSD", decimal: 18},
    {contract: "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d", name: "USDC", decimal: 18},
]

module.exports = {
    currencyList
}