import { Box } from "@chakra-ui/react";

export default function Assets() {
    return (
        <Box>
            
        </Box>
    )
}