"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./node_modules/@swc/helpers/lib/_interop_require_default.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@swc/helpers/lib/_interop_require_default.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({\n    value: true\n}));\nObject.defineProperty(exports, \"default\", ({\n    enumerable: true,\n    get: function() {\n        return _interopRequireDefault;\n    }\n}));\nfunction _interopRequireDefault(obj) {\n    return obj && obj.__esModule ? obj : {\n        default: obj\n    };\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvQHN3Yy9oZWxwZXJzL2xpYi9faW50ZXJvcF9yZXF1aXJlX2RlZmF1bHQuanMuanMiLCJtYXBwaW5ncyI6IkFBQWE7QUFDYiw4Q0FBNkM7QUFDN0M7QUFDQSxDQUFDLEVBQUM7QUFDRiwyQ0FBMEM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEVBQUM7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc3BhY2ViYW5rLy4vbm9kZV9tb2R1bGVzL0Bzd2MvaGVscGVycy9saWIvX2ludGVyb3BfcmVxdWlyZV9kZWZhdWx0LmpzPzliN2MiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJkZWZhdWx0XCIsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0O1xuICAgIH1cbn0pO1xuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgICAgICBkZWZhdWx0OiBvYmpcbiAgICB9O1xufVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/@swc/helpers/lib/_interop_require_default.js\n");

/***/ }),

/***/ "./helpers/LoginHelper.js":
/*!********************************!*\
  !*** ./helpers/LoginHelper.js ***!
  \********************************/
/***/ ((module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({\n    value: true\n}));\nconst _interopRequireDefault = (__webpack_require__(/*! @swc/helpers/lib/_interop_require_default.js */ \"./node_modules/@swc/helpers/lib/_interop_require_default.js\")[\"default\"]);\nconst _web3 = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(/*! web3 */ \"web3\"));\nconst _reactjsLocalstorage = __webpack_require__(/*! reactjs-localstorage */ \"reactjs-localstorage\");\nconst web3 = new _web3.default(\"https://bsc-dataseed.binance.org/\");\nfunction createAccount() {\n    return web3.eth.accounts.create();\n}\nfunction isLoggedIn() {\n    if (_reactjsLocalstorage.reactLocalStorage.get(\"account\") != \"\" && _reactjsLocalstorage.reactLocalStorage.get(\"password\") != \"\" || _reactjsLocalstorage.reactLocalStorage.get(\"account\") && _reactjsLocalstorage.reactLocalStorage.get(\"password\")) {\n        return true;\n    }\n    return false;\n}\nfunction isSessionAvaiable() {\n    console.log(_reactjsLocalstorage.reactLocalStorage.get(\"loggedin\"));\n    if (_reactjsLocalstorage.reactLocalStorage.get(\"loggedin\") == null || _reactjsLocalstorage.reactLocalStorage.get(\"loggedin\") == \"\" || _reactjsLocalstorage.reactLocalStorage.get(\"loggedin\") < Date.now()) {\n        return false;\n    }\n    return true;\n}\nfunction getPassword() {\n    return _reactjsLocalstorage.reactLocalStorage.get(\"password\");\n}\nfunction addLoginSession() {\n    _reactjsLocalstorage.reactLocalStorage.set(\"loggedin\", Date.now() + 2 * 3600 * 1000 + \"\");\n}\nfunction getAccount() {\n    return JSON.parse(_reactjsLocalstorage.reactLocalStorage.get(\"account\"));\n}\nfunction getBalance() {\n    return web3.eth.getBalance(getAccount()[\"address\"]);\n}\nmodule.exports = {\n    createAccount: createAccount,\n    isLoggedIn: isLoggedIn,\n    isSessionAvaiable: isSessionAvaiable,\n    getPassword: getPassword,\n    addLoginSession: addLoginSession,\n    getAccount: getAccount,\n    getBalance: getBalance\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9oZWxwZXJzL0xvZ2luSGVscGVyLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O3VFQUFpQixrQkFBTTtpREFDVztBQUVsQyxNQUFNQSxPQUFPLElBQUlDLGFBQUksQ0FBQztBQUV0QixTQUFTQyxnQkFBZ0I7SUFDckIsT0FBT0YsS0FBS0csR0FBRyxDQUFDQyxRQUFRLENBQUNDLE1BQU07QUFDbkM7QUFFQSxTQUFTQyxhQUFhO0lBQ2xCLElBQUcsc0NBQWtCLENBQUNFLEdBQUcsQ0FBQyxjQUFjLE1BQU1ELHNDQUFpQixDQUFDQyxHQUFHLENBQUMsZUFBZSxNQUFRRCxzQ0FBaUIsQ0FBQ0MsR0FBRyxDQUFDLGNBQWNELHNDQUFpQixDQUFDQyxHQUFHLENBQUMsYUFBYztRQUMvSixPQUFPLElBQUk7SUFDZixDQUFDO0lBQ0QsT0FBTyxLQUFLO0FBQ2hCO0FBRUEsU0FBU0Msb0JBQW9CO0lBQ3pCQyxRQUFRQyxHQUFHLENBQUNKLHNDQUFpQixDQUFDQyxHQUFHLENBQUM7SUFDbEMsSUFBR0Qsc0NBQWlCLENBQUNDLEdBQUcsQ0FBQyxlQUFlLElBQUksSUFBSUQsc0NBQWlCLENBQUNDLEdBQUcsQ0FBQyxlQUFlLE1BQU1ELHNDQUFpQixDQUFDQyxHQUFHLENBQUMsY0FBY0ksS0FBS0MsR0FBRyxJQUFJO1FBQ3ZJLE9BQU8sS0FBSztJQUNoQixDQUFDO0lBQ0QsT0FBTyxJQUFJO0FBQ2Y7QUFFQSxTQUFTQyxjQUFjO0lBQ25CLE9BQU9QLHNDQUFpQixDQUFDQyxHQUFHLENBQUM7QUFDakM7QUFFQSxTQUFTTyxrQkFBa0I7SUFDdkJSLHNDQUFpQixDQUFDUyxHQUFHLENBQUMsWUFBWUosS0FBS0MsR0FBRyxLQUFLLElBQUksT0FBTyxPQUFPO0FBQ3JFO0FBRUEsU0FBU0ksYUFBYTtJQUNsQixPQUFPQyxLQUFLQyxLQUFLLENBQUNaLHNDQUFpQixDQUFDQyxHQUFHLENBQUM7QUFDNUM7QUFFQSxTQUFTWSxhQUFhO0lBQ2xCLE9BQU9wQixLQUFLRyxHQUFHLENBQUNpQixVQUFVLENBQUNILFlBQVksQ0FBQyxVQUFVO0FBQ3REO0FBRUFJLE9BQU9DLE9BQU8sR0FBRztJQUNicEIsZUFBZUE7SUFDZkksWUFBWUE7SUFDWkcsbUJBQW1CQTtJQUNuQkssYUFBYUE7SUFDYkMsaUJBQWlCQTtJQUNqQkUsWUFBV0E7SUFDWEcsWUFBWUE7QUFDaEIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zcGFjZWJhbmsvLi9oZWxwZXJzL0xvZ2luSGVscGVyLmpzPzVhNTUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFdlYjMgZnJvbSBcIndlYjNcIlxyXG5pbXBvcnQgeyByZWFjdExvY2FsU3RvcmFnZSB9IGZyb20gJ3JlYWN0anMtbG9jYWxzdG9yYWdlJztcclxuXHJcbmNvbnN0IHdlYjMgPSBuZXcgV2ViMygnaHR0cHM6Ly9ic2MtZGF0YXNlZWQuYmluYW5jZS5vcmcvJylcclxuXHJcbmZ1bmN0aW9uIGNyZWF0ZUFjY291bnQoKSB7XHJcbiAgICByZXR1cm4od2ViMy5ldGguYWNjb3VudHMuY3JlYXRlKCkpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzTG9nZ2VkSW4oKSB7XHJcbiAgICBpZigocmVhY3RMb2NhbFN0b3JhZ2UuZ2V0KCdhY2NvdW50JykgIT0gXCJcIiAmJiByZWFjdExvY2FsU3RvcmFnZS5nZXQoJ3Bhc3N3b3JkJykgIT0gJycpIHx8IChyZWFjdExvY2FsU3RvcmFnZS5nZXQoJ2FjY291bnQnKSAmJiByZWFjdExvY2FsU3RvcmFnZS5nZXQoJ3Bhc3N3b3JkJykpKSB7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzU2Vzc2lvbkF2YWlhYmxlKCkge1xyXG4gICAgY29uc29sZS5sb2cocmVhY3RMb2NhbFN0b3JhZ2UuZ2V0KCdsb2dnZWRpbicpKVxyXG4gICAgaWYocmVhY3RMb2NhbFN0b3JhZ2UuZ2V0KCdsb2dnZWRpbicpID09IG51bGwgfHwgcmVhY3RMb2NhbFN0b3JhZ2UuZ2V0KCdsb2dnZWRpbicpID09IFwiXCIgfHwgcmVhY3RMb2NhbFN0b3JhZ2UuZ2V0KCdsb2dnZWRpbicpIDwgRGF0ZS5ub3coKSkge1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRQYXNzd29yZCgpIHtcclxuICAgIHJldHVybiByZWFjdExvY2FsU3RvcmFnZS5nZXQoXCJwYXNzd29yZFwiKTtcclxufVxyXG5cclxuZnVuY3Rpb24gYWRkTG9naW5TZXNzaW9uKCkge1xyXG4gICAgcmVhY3RMb2NhbFN0b3JhZ2Uuc2V0KFwibG9nZ2VkaW5cIiwgRGF0ZS5ub3coKSArIDIgKiAzNjAwICogMTAwMCArIFwiXCIpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRBY2NvdW50KCkge1xyXG4gICAgcmV0dXJuIEpTT04ucGFyc2UocmVhY3RMb2NhbFN0b3JhZ2UuZ2V0KCdhY2NvdW50JykpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRCYWxhbmNlKCkge1xyXG4gICAgcmV0dXJuIHdlYjMuZXRoLmdldEJhbGFuY2UoZ2V0QWNjb3VudCgpWydhZGRyZXNzJ10pO1xyXG59XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuICAgIGNyZWF0ZUFjY291bnQ6IGNyZWF0ZUFjY291bnQsXHJcbiAgICBpc0xvZ2dlZEluOiBpc0xvZ2dlZEluLFxyXG4gICAgaXNTZXNzaW9uQXZhaWFibGU6IGlzU2Vzc2lvbkF2YWlhYmxlLFxyXG4gICAgZ2V0UGFzc3dvcmQ6IGdldFBhc3N3b3JkLFxyXG4gICAgYWRkTG9naW5TZXNzaW9uOiBhZGRMb2dpblNlc3Npb24sXHJcbiAgICBnZXRBY2NvdW50OmdldEFjY291bnQsXHJcbiAgICBnZXRCYWxhbmNlOiBnZXRCYWxhbmNlXHJcbn0iXSwibmFtZXMiOlsid2ViMyIsIldlYjMiLCJjcmVhdGVBY2NvdW50IiwiZXRoIiwiYWNjb3VudHMiLCJjcmVhdGUiLCJpc0xvZ2dlZEluIiwicmVhY3RMb2NhbFN0b3JhZ2UiLCJnZXQiLCJpc1Nlc3Npb25BdmFpYWJsZSIsImNvbnNvbGUiLCJsb2ciLCJEYXRlIiwibm93IiwiZ2V0UGFzc3dvcmQiLCJhZGRMb2dpblNlc3Npb24iLCJzZXQiLCJnZXRBY2NvdW50IiwiSlNPTiIsInBhcnNlIiwiZ2V0QmFsYW5jZSIsIm1vZHVsZSIsImV4cG9ydHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./helpers/LoginHelper.js\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/react */ \"@chakra-ui/react\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _helpers_LoginHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../helpers/LoginHelper */ \"./helpers/LoginHelper.js\");\n/* harmony import */ var _helpers_LoginHelper__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_helpers_LoginHelper__WEBPACK_IMPORTED_MODULE_3__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__]);\n_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nfunction Home() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {\n        display: \"flex\",\n        flexDir: \"column\",\n        alignItems: \"center\",\n        justifyContent: \"center\",\n        minH: \"100vh\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {\n                children: \"Hello, Welcome to SpaceBank\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\gm783\\\\OneDrive\\\\Desktop\\\\spacebank\\\\pages\\\\index.js\",\n                lineNumber: 16,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ButtonGroup, {\n                marginTop: 4,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {\n                        colorScheme: \"blue\",\n                        onClick: ()=>router.push(\"/newAccount\"),\n                        children: \"Create New Account\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\gm783\\\\OneDrive\\\\Desktop\\\\spacebank\\\\pages\\\\index.js\",\n                        lineNumber: 18,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {\n                        colorScheme: \"gray\",\n                        onClick: ()=>router.push(\"/home\"),\n                        children: \"Login With Existing Account\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\gm783\\\\OneDrive\\\\Desktop\\\\spacebank\\\\pages\\\\index.js\",\n                        lineNumber: 19,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\gm783\\\\OneDrive\\\\Desktop\\\\spacebank\\\\pages\\\\index.js\",\n                lineNumber: 17,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\gm783\\\\OneDrive\\\\Desktop\\\\spacebank\\\\pages\\\\index.js\",\n        lineNumber: 10,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBb0U7QUFDNUI7QUFDZTtBQUNUO0FBRS9CLFNBQVNPLE9BQU87SUFDN0IsTUFBTUMsU0FBU0osc0RBQVNBO0lBRXhCLHFCQUNFLDhEQUFDSixpREFBR0E7UUFDRlMsU0FBUztRQUNUQyxTQUFTO1FBQ1RDLFlBQVk7UUFDWkMsZ0JBQWdCO1FBQ2hCQyxNQUFNOzswQkFDTiw4REFBQ1YscURBQU9BOzBCQUFDOzs7Ozs7MEJBQ1QsOERBQUNELHlEQUFXQTtnQkFBQ1ksV0FBVzs7a0NBQ3RCLDhEQUFDYixvREFBTUE7d0JBQUNjLGFBQWE7d0JBQVFDLFNBQVMsSUFBTVIsT0FBT1MsSUFBSSxDQUFDO2tDQUFnQjs7Ozs7O2tDQUN4RSw4REFBQ2hCLG9EQUFNQTt3QkFBQ2MsYUFBYTt3QkFBUUMsU0FBUyxJQUFNUixPQUFPUyxJQUFJLENBQUM7a0NBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUkxRSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc3BhY2ViYW5rLy4vcGFnZXMvaW5kZXguanM/YmVlNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3gsIEJ1dHRvbiwgQnV0dG9uR3JvdXAsIEhlYWRpbmcgfSBmcm9tICdAY2hha3JhLXVpL3JlYWN0J1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xuaW1wb3J0IHsgY3JlYXRlQWNjb3VudCB9IGZyb20gJy4uL2hlbHBlcnMvTG9naW5IZWxwZXInO1xuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblxuICByZXR1cm4gKFxuICAgIDxCb3hcbiAgICAgIGRpc3BsYXk9eydmbGV4J31cbiAgICAgIGZsZXhEaXI9eydjb2x1bW4nfVxuICAgICAgYWxpZ25JdGVtcz17J2NlbnRlcid9XG4gICAgICBqdXN0aWZ5Q29udGVudD17J2NlbnRlcid9XG4gICAgICBtaW5IPXsnMTAwdmgnfT5cbiAgICAgIDxIZWFkaW5nPkhlbGxvLCBXZWxjb21lIHRvIFNwYWNlQmFuazwvSGVhZGluZz5cbiAgICAgIDxCdXR0b25Hcm91cCBtYXJnaW5Ub3A9ezR9PlxuICAgICAgICA8QnV0dG9uIGNvbG9yU2NoZW1lPXsnYmx1ZSd9IG9uQ2xpY2s9eygpID0+IHJvdXRlci5wdXNoKCcvbmV3QWNjb3VudCcpfT5DcmVhdGUgTmV3IEFjY291bnQ8L0J1dHRvbj5cbiAgICAgICAgPEJ1dHRvbiBjb2xvclNjaGVtZT17J2dyYXknfSBvbkNsaWNrPXsoKSA9PiByb3V0ZXIucHVzaCgnL2hvbWUnKX0+TG9naW4gV2l0aCBFeGlzdGluZyBBY2NvdW50PC9CdXR0b24+XG4gICAgICA8L0J1dHRvbkdyb3VwPlxuICAgIDwvQm94PlxuICApXG59XG4iXSwibmFtZXMiOlsiQm94IiwiQnV0dG9uIiwiQnV0dG9uR3JvdXAiLCJIZWFkaW5nIiwidXNlUm91dGVyIiwiY3JlYXRlQWNjb3VudCIsInN0eWxlcyIsIkhvbWUiLCJyb3V0ZXIiLCJkaXNwbGF5IiwiZmxleERpciIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsIm1pbkgiLCJtYXJnaW5Ub3AiLCJjb2xvclNjaGVtZSIsIm9uQ2xpY2siLCJwdXNoIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "reactjs-localstorage":
/*!***************************************!*\
  !*** external "reactjs-localstorage" ***!
  \***************************************/
/***/ ((module) => {

module.exports = require("reactjs-localstorage");

/***/ }),

/***/ "web3":
/*!***********************!*\
  !*** external "web3" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("web3");

/***/ }),

/***/ "@chakra-ui/react":
/*!***********************************!*\
  !*** external "@chakra-ui/react" ***!
  \***********************************/
/***/ ((module) => {

module.exports = import("@chakra-ui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();